class GameController < ApplicationController
  def start
  end

  def result
  end
end
