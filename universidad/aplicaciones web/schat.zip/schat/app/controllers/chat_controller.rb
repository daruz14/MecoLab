class ChatController < ApplicationController
  def index
  end
end
