
def random_word(min_length = 1, max_length = 10)
  characters = ('a'..'z')
  all_characters_array = characters.to_a * (max_length - min_length)
  chosen_characters_array = all_characters_array.shuffle.first( rand(min_length..max_length) )
  chosen_characters_array.join
end
def random_author
  [
    "Henderson, Lauren", "Aslan, Reza", "Masson, Sophie", "Feinstein, John", "Sandford, John", "Brashares, Ann",
    "Hagen, George", "Lion, Melissa", "Scott, Michael", "Ransome, James", "Park, Barbara", "Nixon, Joan Lowery",
    "Padian, Maria", "Roth, Ty", "Shovan, Laura", "Hinton, S.E.", "Walrath, Dana", "Mankell, Henning",
    "Holm, Jennifer L.", "Murphy, Rita", "Torrey, Richard", "Neff, Henry H.", "Townley, Roderick", "Schmidt, Amy",
    "Harmon, Michael", "Slade, Arthur", "Rey, Luis", "Thompson, Holly", "Zindel, Paul", "Augarde, Steve",
    "Humphreys, Chris", "Bryant, Jen", "Tate, Eleanora", "Cooper, Michelle", "L’Engle, Madeleine",
    "Klause, Annette Curtis", "Potter, Giselle", "Berk, Josh", "Marchetta, Melina", "Woodruff, Elvira",
    "Kinsey-Warnock, Natalie", "Snyder, Zilpha Keatley", "Boyd, Maria", "Crowley, Cath", "Basye, Dale E.",
    "Brande, Robin", "Holm, Matt", "Lurie, April", "Duncan, Lois", "Coville, Bruce", "Gormley, Beatrice",
    "Salisbury, Graham", "Dowd, Siobhan", "Monir, Alexandra", "Hart, Alison", "Spinner, Stephanie",
    "Kittredge, Caitlin", "Santore, Charles", "Griffin, Adele", "Hanley, Victoria", "Little, Kimberley Griffiths",
    "Clement-Moore, Rosemary", "Ayres, Katherine", "Shank, Marilyn Sue", "Torrey, Michele", "Runyon, Brent",
    "Wyeth, Sharon Dennis", "Jocelyn, Marthe", "Rosenthal, Lorraine Zago", "Namioka, Lensey", "Kizer, Amber",
    "Schmais, Libby", "Peters, Julie Anne", "Aiken, Joan", "Hoffmann, Kerry Cohen", "Bauer, Cat", "Price, Lissa",
    "Hyde, Catherine Ryan", "Levithan, David", "Burg, Shana", "Couloumbis, Audrey", "King, A.S.", "Leveen, Tom",
    "Alvarez, Julia", "Mora, Pat", "Choi, Sook Nyul", "Dorfman, Joaquin", "Roy, Ron", "Almond, David",
    "Snyder, Laurel", "Stauffacher, Sue", "Smith, Sherri L.", "Hughes, Mark Peter", "Ryan, Carrie", "Lockhart, E.",
    "Vincent, Erin", "Raschka, Chris", "Perl, Erica S.", "Craddock, Erik", "Shukert, Rachel"
  ].sample
end

# crear varios videos
videos = []
100.times do
  id = rand(1000)
  name = random_word 3
  title = random_word(1, 7) + " " + random_word + " " + random_word(1, 7)
  author = random_author
  description = ""
  10.times do
    description += random_word + " "
  end
  video = Videos::Video.build(id, name, title, author, description)
  videos << video
end

#puts videos.inspect


# Agrega todos los videos a un nuevo "Video Store"


a_video = videos.sample
# pregunta a tu video store donde tiene este video ("a_video")