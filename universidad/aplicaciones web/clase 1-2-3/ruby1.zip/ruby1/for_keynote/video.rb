class Video

  attr_accessor :name, :title, :author, :description, :data
  attr_reader :id, :name_counter

  def initialize(id)
    @id = id
    @name_counter = 0
  end

  def name=(new_name)
    @name = new_name
    inc_name_counter
  end

  def url
    "/videos/#{author[0]}/#{id}"
  end

  private

  def inc_name_counter
    @name_counter += 1
  end

end