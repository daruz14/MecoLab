
n0 = 61
n1 = rand(1..100)

# if

if n1 < n0
  puts "n1 es menor a n0: #{n1} < #{n0}"
end

if n1 < n0 then puts "n1 es menor a n0: #{n1} < #{n0}" end

puts "n1 es menor a n0: #{n1} < #{n0}" if n1 < n0

if n1 < n0
  puts "n1 es menor a n0: #{n1} < #{n0}"
else
  puts "n1 es mayor o igual a n0: #{n1} >= #{n0}"
end

if n1 < n0 then puts("n1 es menor a n0: #{n1} < #{n0}")
elsif n1 == n0 then puts("OMG, son iguales: #{n1} == #{n0}")
else puts("n1 es mayor a n0: #{n1} >= #{n0}")
end



an_array = [2,7,1,4]

an_array.each do |value|
  puts value
end

an_array.each_with_index do |value,i|
  puts "#{i} -> #{value} == #{an_array[i]}"
end

a_hash = {"b" => 2, "k" => 7, "n" => "oso"}

a_hash.each do |key,value|
  puts "#{key} -> #{value} == #{a_hash[key]}"
end

