# ###########
# Arreglo

an_array = Array.new

an_array.push 2
an_array.push 7
an_array.push 1
an_array.push 4

puts an_array.inspect
# imprime [2,7,1,4]

# otra forma:
an_array = [2,7,1,4]
puts an_array.inspect


# ###########
# Rango

a_range = Range.new(1,20) # del 1 al 20, inclusive
a_range = Range.new(1,20,true) # del 1 al 19, inclusive

a_range = 1..20 # del 1 al 20, inclusive
a_range = 1...20 # del 1 al 19, inclusive

puts a_range.to_a.inspect
# imprime [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

a_range = ('a'..'f')

puts a_range.to_a.inspect
# imprime ["a", "b", "c", "d", "e", "f"]


# ###########
# Hash
a_hash = {} # lo mismo que Hash.new
a_hash["hola"] = 2
a_hash["mundo"] = "mundoso"
a_hash[6] = "vaca"
a_hash[1] = "ciones"

puts a_hash.inspect

# otra forma
a_hash = {
  "hola" => 2,
  "mundo" => "mundoso",
  6 => "vaca",
  1 => "ciones"
}

puts a_hash.inspect
# imprime {"hola"=>2, "mundo"=>"mundoso", 6=>"vaca", 1=>"ciones"}