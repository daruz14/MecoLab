# V1
class Video

  def initialize(id)
    @id = id;
  end

  def id()
    return @id;
  end

  def id=(new_id)
    @id = new_id;
  end

  def name()
    return @name;
  end

  def name=(name)
    @name = name;
  end

end

my_video = Video.new(1);
my_video.name=("My video 1.0");

puts("Tengo un video con id: #{my_video.id()} de nombre '#{my_video.name()}'");
# Tengo un video con id: 1 de nombre 'My video 1.0'





#V2
class Video

  def initialize id
    @id = id
  end

  def id
    @id
  end

  def id= new_id
    @id = new_id
  end

  def name
    @name
  end

  def name= name
    @name = name
  end

end

my_video = Video.new 2
my_video.name= "My video 2.0"

puts "Tengo un video con id: #{my_video.id} de nombre '#{my_video.name}'"
# Tengo un video con id: 2 de nombre 'My video 2.0'





#V2.1
class Video

  def initialize(id)
    @id = id
  end

  def id
    @id
  end

  def id=(new_id)
    @id = new_id
  end

  def name
    @name
  end

  def name=(name)
    @name = name
  end

end

my_video = Video.new(2)
my_video.name= "My video 2.1"

puts "Tengo un video con id: #{my_video.id} de nombre '#{my_video.name}'"
# Tengo un video con id: 2 de nombre 'My video 2.1'





#V3
class Video

  attr_accessor :id, :name

  def initialize(id)
    @id = id
  end

end

my_video = Video.new(3)
my_video.name= "My video 3.0"

puts "Tengo un video con id: #{my_video.id} de nombre '#{my_video.name}'"
# Tengo un video con id: 3 de nombre 'My video 3.0'




#V4
class Video

  attr_accessor :id, :name
  attr_reader :name_counter

  def initialize(id)
    @id = id
    @name_counter = 0
  end

  def name=(new_name)
    @name = new_name
    inc_name_counter
  end

  private

  def inc_name_counter
    @name_counter += 1
  end

end

my_video = Video.new(4)
my_video.name= "My video 1.0"
my_video.name= "My video 2.0"
my_video.name= "My video 2.1"
my_video.name= "My video 3.0"
my_video.name= "My video 4.0"

puts "Tengo un video de nombre '#{my_video.name}' (#{my_video.name_counter} nombres)"
# Tengo un video de nombre 'My video 4.0' (5 nombres)






class Video

  attr_accessor :name, :title, :author, :description, :data
  attr_reader :id, :name_counter

  def initialize(id)
    @id = id
    @name_counter = 0
  end

  def name=(new_name)
    @name = new_name
    inc_name_counter
  end

  def url
    "/videos/#{author[0]}/#{id}"
  end

  private

  def inc_name_counter
    @name_counter += 1
  end

end
