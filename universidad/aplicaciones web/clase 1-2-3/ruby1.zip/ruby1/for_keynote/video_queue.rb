require 'video'

# cola de videos
class VideoQueue

  def initialize
    @videos = [] # Array.new
  end

  # Agrega un video a la cola
  def add(video)
    @videos << video
  end

  # entrega y "elimina" el primer video de la cola
  def play
    @videos.shift
  end

  # dice si no hay videos en la cola
  def empty?
    @videos.empty?
  end

  # entrega el numero de videos en cola
  def size
    @videos.length
  end

end