
module Videos
  require_relative 'video_node'

  class VideoStore

    def initialize
      @root_node = nil
    end

    # guarda un video
    def save(video)
      # TODO
    end

    # tienes guardado el video?
    def has?(video)
      # TODO
    end

    # donde esta?
    # Ejemplos de respuestas posibles:
    # nil - no lo tengo
    # '' - esta "aqui mismo"
    # 'I' - esta a la izquierda
    # 'D' - esta a la derecha
    # 'IDDII' esta a la izquierda, derecha, derecha, izquierda, izquierda, y ahi
    #
    def where_is?(video)
      if has?(video)
        @root_node.where_is?(video)
      end
    end

  end
end