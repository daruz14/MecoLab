module Videos
  class VideoNode

    attr_accessor :left, :right

    def initialize(video)
      @video = video
      @left = nil
      @right = nil
    end

    def store(video)
      unless is_my_video?(video)
        # si es menor va a la derecha
        if video.id < @video.id
          if left.present?
            left.store(video)
          else
            left = new(video)
          end
        else
          if right.present?
            right.store(video)
          else
            right = new(video)
          end
        end
      end
    end

    # tengo yo el video?
    def is_my_video?(some_video)
      @video.id == some_video.id
    end

    # tengo yo el video, o uno de mis hijos?
    def has?(some_video)
      # TODO
      # lo tendre yo?
      # si no, por el valor, si es menor, debe estar a la derecha, sino, a la izquierda
    end


    def where_is?(video)
      if has?(video)
        # por aqui debe estar el video ...
        # TODO
        "III" #entregamos un valor de mentira mientras tanto
      else
        # no, aca no esta el video
        nil
      end
    end
  end
end
