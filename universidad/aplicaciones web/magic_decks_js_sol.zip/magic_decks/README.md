# README

Nuevo proyecto de prueba para Redvel.

Para cargar la base de datos con cartas, usar las instrucciones de https://github.com/JAndritsch/mtgextractor

Ejemplo:

```bash
SET="Oath of the Gatewatch" rake mtgextractor:update_set
SET="Battle for Zendikar" rake mtgextractor:update_set
SET="Magic Origins" rake mtgextractor:update_set
SET="Dragons of Tarkir" rake mtgextractor:update_set
SET="Fate Reforged" rake mtgextractor:update_set
SET="Khans of Tarkir" rake mtgextractor:update_set
```